﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShortPeakRobot.Robots.Algorithms.Models.ShortPeakModels
{
    public class Peak
    {
        public decimal Volume { get; set; }
        public DateTime Date { get; set; }
    }
}
