﻿using ShortPeakRobot.Robots.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShortPeakRobot.Constants
{
    public static class SymbolInitialization
    {
        public static readonly List<string> list =new List<string>()
        {
            "ETHUSDT" ,"BTCUSDT" ,"BNBUSDT" ,"SOLUSDT" ,"XRPUSDT","ADAUSDT" ,"DOGEUSDT" ,"LTCUSDT"
        };
    }
}
