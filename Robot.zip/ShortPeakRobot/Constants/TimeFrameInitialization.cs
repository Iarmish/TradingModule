﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShortPeakRobot.Constants
{
    public static class TimeFrameInitialization
    {
        public static readonly List<int> list = new List<int>()
        {
             60, 86400
        };
    }
}
