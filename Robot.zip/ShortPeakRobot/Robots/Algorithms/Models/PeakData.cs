﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShortPeakRobot.Robots.Algorithms.Models
{
    public class PeakData
    {
        public decimal FirstPeak { get; set; }
        public decimal OppositePeak { get; set; }
    }
}
