﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShortPeakRobot.Robots.Algorithms.Models.ShortPeakModels
{
    public class ShortPeakModel
    {
        public decimal FirstCandle { get; set; }
        public decimal SecondCandle { get; set; }
    }
}
