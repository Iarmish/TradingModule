﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShortPeakRobot.Robots.Algorithms.Models
{
    public class DayPeaks
    {
        public decimal High { get; set; }
        public decimal Low { get; set; }
    }
}
